import { SearchResult, PaginatedResponse } from '../types';
import { SEARCH_CONFIG } from '../constants';

// Cache for fetched products
let cachedProducts: SearchResult[] | null = null;

// Fetch products from API in batches
async function fetchAllProducts(): Promise<SearchResult[]> {
  if (cachedProducts) {
    return cachedProducts;
  }

  try {
    const allProducts: SearchResult[] = [];
    let offset = 0;
    const limit = 100; // Fetch 100 products at a time
    let hasMore = true;

    // Fetch products in batches until we have enough or no more are available
    while (hasMore && allProducts.length < 500) {
      const response = await fetch(
        `https://api.escuelajs.co/api/v1/products?offset=${offset}&limit=${limit}`
      );

      if (!response.ok) {
        throw new Error(`Failed to fetch products: ${response.statusText}`);
      }

      const products: SearchResult[] = await response.json();

      if (products.length === 0) {
        hasMore = false;
      } else {
        allProducts.push(...products);
        offset += limit;

        // If we got fewer products than requested, we've reached the end
        if (products.length < limit) {
          hasMore = false;
        }
      }
    }

    cachedProducts = allProducts;
    return cachedProducts;
  } catch (error) {
    console.error('Error fetching products:', error);
    throw error;
  }
}

export async function searchItems(
  query: string,
  page: number = 1,
  pageSize: number = SEARCH_CONFIG.PAGE_SIZE
): Promise<PaginatedResponse> {
  if (!query.trim()) {
    throw new Error('Query cannot be empty');
  }

  try {
    // Fetch all products (with caching)
    const allProducts = await fetchAllProducts();

    // Filter by query (search in title)
    const lowerQuery = query.toLowerCase();
    const filtered = allProducts.filter((item) =>
      item.title.toLowerCase().includes(lowerQuery)
    );

    // Paginate results
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const paginatedData = filtered.slice(startIndex, endIndex);
    const hasMore = endIndex < filtered.length;

    return {
      data: paginatedData,
      hasMore,
      total: filtered.length,
    };
  } catch (error) {
    console.error('Error in searchItems:', error);
    throw error;
  }
}
