import { Title, Text, Box, Group, Badge } from '@mantine/core';

export function Header() {
    return (
        <Box mb="xl">
            <Group gap="xs" mb="md">
                <Title order={1}>Searchable Dropdown</Title>
                <Badge color="blue" variant="light" size="lg">
                    React 19
                </Badge>
            </Group>
            <Text c="dimmed" size="lg" mb="md">
                High-performance autocomplete component with advanced features
            </Text>
            <Group gap="xs">
                <Badge variant="dot" color="green" size="sm">
                    Debounced Search
                </Badge>
                <Badge variant="dot" color="blue" size="sm">
                    Infinite Scroll
                </Badge>
                <Badge variant="dot" color="purple" size="sm">
                    Keyboard Navigation
                </Badge>
                <Badge variant="dot" color="orange" size="sm">
                    Race Condition Safe
                </Badge>
            </Group>
        </Box>
    );
}
